﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaunDeObjetos : MonoBehaviour
{
    public GameObject barreiraPrefab;

    public float ratespawn;

    public float currentTime;

    public int posicao;

    private float x;

    // Start is called before the first frame update
    void Start()
    {
        currentTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        currentTime += Time.deltaTime;
        if (currentTime >= ratespawn)
        {
            currentTime = 0;

            posicao = Random.Range(-10, 10);
            GameObject tempPrefab = Instantiate(barreiraPrefab) as GameObject;
            tempPrefab.transform.position = new Vector3(posicao, tempPrefab.transform.position.y, tempPrefab.transform.position.z);
        }
    }
}
