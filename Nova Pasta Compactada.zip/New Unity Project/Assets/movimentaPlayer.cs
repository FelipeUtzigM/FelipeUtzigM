﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movimentaPlayer : MonoBehaviour
{
    public float speed = 9;

    public bool andando;

    public int vida = 3;

    private float directionX;

    public GameObject chão;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        vida = chão.GetComponent<PerdeVida>().vida;
    }
    private void FixedUpdate()
    {
        MovePlayer();
    }

        void MovePlayer()
    {
        //capturar a direção de deslocamento em x e z
        directionX = Input.GetAxis("Horizontal");
       // directionZ = Input.GetAxis("Vertical");

        // rotacionar camera baseado no input do mouse

       

        // movimentar o personagem:
        transform.Translate(new Vector2(directionX,0) * speed * Time.deltaTime);
        //transform.Translate(new Vector2(0, 0, directionZ) * speed * Time.deltaTime);
        

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag.Equals("ObjetoPegavel"))
            Destroy(other.gameObject);
    }


}