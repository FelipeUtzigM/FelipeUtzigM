﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PerdeVida : MonoBehaviour
{
    public GameObject Player;

    public int vida = 3;

    public int Dano = 0;

    public GameObject contador;

    public GameObject contador2;

    public GameObject contador3;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag.Equals("ObjetoPegavel"))
            Dano = 1;
        vida = Player.GetComponent<movimentaPlayer>().vida;

        
    }
    public void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag.Equals("ObjetoPegavel"))
        {
            if (vida == 3)
            {
                contador.SetActive(false);
            }

            if (vida == 2)
            {
                contador2.SetActive(false);
            }

            if (vida == 1)
            {
                contador3.SetActive(false);

                SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
            }
            vida -= Dano;

            Dano = 0;
            


            Destroy(other.gameObject);
        }
    }
}
